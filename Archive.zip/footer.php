    <footer class="navbar navbar-expand-lg navbar-dark bg-dark fixed-bottom py-2">
        <div class="container">
            <a href="https://pratyayrudra.com" class="mx-auto"><span class="text-muted">Made with ♥ </span><span
                    class="text-light">Pratyay Rudra</span></a>
            <ul class="navbar-nav flex-row m-auto justify-content-between">
                <li class="nav-item">
                    <a class="nav-link" href="https://www.facebook.com/rudrapratyay1999"><i class="fa fa-facebook-f"
                            aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://www.instagram.com/pratyayrudra/"><i class="fa fa-instagram"
                            aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://twitter.com/pratyayrudra"><i class="fa fa-twitter"
                            aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://github.com/pratyayrudra"><i class="fa fa-github"
                            aria-hidden="true"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://in.linkedin.com/in/pratyayrudra"><i class="fa fa-linkedin"
                            aria-hidden="true"></i></a>
                </li>
            </ul>
        </div>
    </footer>

    </body>

    </html>